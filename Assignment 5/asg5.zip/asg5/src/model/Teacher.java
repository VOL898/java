package model;

public interface Teacher {
    void teaching();
}
